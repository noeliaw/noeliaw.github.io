function triggerWinAnimation(repeatCount = 2) {
    const winAnimation = document.getElementById("win-animation");
    winAnimation.style.display = "flex"; // Show the full-screen animation
  
    const numberCount = 10; // Number of numbers to generate
    for (let i = 0; i < numberCount; i++) {
      const number = document.createElement("div");
  
      number.classList.add("number");
      number.textContent = Math.floor(Math.random() * 100); // Random number
      const number2 = document.createElement("div");
      number2.classList.add("number2");
      number2.textContent = Math.floor(Math.random() * 100); // Random number
  
      const number3 = document.createElement("div");
      number3.classList.add("number3");
      number3.textContent = Math.floor(Math.random() * 100); // Random number
      // Random angle for radial direction
      const angle = Math.random() * 2 * Math.PI;
  
      // Distance for the number to travel (adjust as needed)
      const distance = Math.random() * 200 + 200; // 200px to 400px
  
      // Calculate the x and y translation values
      const x = Math.cos(angle) * distance + "px";
      const y = Math.sin(angle) * distance + "px";
      const x2 = Math.cos(Math.random() * 2 * Math.PI) * distance + "px";
      const y2 = Math.sin(Math.random() * 2 * Math.PI) * distance + "px";
      const x3 = Math.cos(Math.random() * 2 * Math.PI) * distance + "px";
      const y3 = Math.sin(Math.random() * 2 * Math.PI) * distance + "px";
  
      // Set CSS variables for the animation
      number.style.setProperty("--x", x);
      number.style.setProperty("--y", y);
      number2.style.setProperty("--x", x2);
      number2.style.setProperty("--y", y2);
      number3.style.setProperty("--x", x3);
      number3.style.setProperty("--y", y3);
      // Add the number to the animation container
      winAnimation.appendChild(number);
      winAnimation.appendChild(number2);
      winAnimation.appendChild(number3);
      // Remove the number after the animation completes
      setTimeout(() => {
        number.remove();
      }, 2000);
    }
  
    // If more repeats are needed, call the function again after a delay
    if (repeatCount > 1) {
      setTimeout(() => {
        triggerWinAnimation(repeatCount - 1);
      }, 2100); // Slightly more than the animation duration to ensure smooth repetition
    } else {
      // Hide the animation container after the last repetition
      setTimeout(() => {
        winAnimation.style.display = "none";
      }, 2500);
    }
  }
  // Example game logic
  function checkWinCondition() {
    // Your game logic to check if the player has won
    const hasWon = true; // This should be replaced with your actual win condition
    if (hasWon) {
      triggerWinAnimation();
    }
  }