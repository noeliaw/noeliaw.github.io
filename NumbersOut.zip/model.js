
const Model = {
    nro_colums: 2,
    last_number: null,
    cards_played: 2,
    minCardPlayed: 2,
    cards_left:0,
    lastCardPlayed: [],
    selectedButton: null, // Track the currently selected button
    mode: "helper",
    time: 0,
    buttonNumbers: [],
    activeNumbers: [],
    activeHand: [{ id: 0 }], // Ensure this is an array
    columnPlayed: [],
    undo:0,
    // Other existing methods...
    initializeButtons() {
      this.buttonNumbers = [];
      for (let i = 2; i <= this.last_number - 1; i++) {
        this.buttonNumbers.push({
          id: i,
          state: "active",
          upTrick: "active",
          downTrick: "active",
        });
      }
    },
    resetActiveHand(){
      Model.activeHand = [];
    },
    initialTricksMade(){
      Model.tricksMade = 0;
    },
    setActiveButtonNumber(id){
      Model.buttonNumbers[id-2].state = "active";
    },
    setInactiveButtonNumber(id){
      Model.buttonNumbers[id-2].state = "inactive";
    },
    setNullSelectedButton(){
      Model.selectedButton = null;
    },
    resetLastCardPlayed(){
      Model. lastCardPlayed= [];
    },
    initialCardsPlayed(){
      Model.cards_played = Model.minCardPlayed;
    },
    getLastCardPlayed(){
      return Model.lastCardPlayed.pop();
    },
    setHelperMode(){
      Model.mode = "helper";
    },
    setGameMode(){
      Model.mode = "game";
    },
    increaseUndo(){
      Model.undo=Model.undo+1;
    },
    resetUndo(){
      Model.undo=0;
    },
    setCardsLeft(){
      Model.cards_left = Model.getActiveNumbers().length;
    },
    increaseTricksMade(){
      Model.tricksMade = Model.tricksMade + 1;
    },
    increaseCardsLeft(){
      Model.cards_left = Model.cards_left + 1;
    },
    decreaseCardsPlayed(){
      Model.cards_played = Model.cards_played - 1;
    },
    increaseCardsPlayed(){
      Model.cards_played = Model.cards_played + 1;
    },
    resetButtonNumbers() {
      this.buttonNumbers.forEach((button) => {
        button.state = "active";
      });
    },
    setActiveHand(handid) {
      this.activeHand.push({
        id: handid,
      });
      return this.activeHand;
    },
    removeActiveHand(handid) {
      this.activeHand = this.activeHand.filter((hand) => hand.id !== handid);
      return this.activeHand;
    },
    checkIsInHand(randomid) {
      // console.log(this.activeHand); // Log to check the value of activeHand
  
      return this.activeHand.some((hand) => hand.id === randomid);
    },
    getActiveNumbers() {
      this.activeNumbers = this.buttonNumbers.filter(
        (button) => button.state === "active"
      );
      return this.activeNumbers;
    },
    setUpTrick(id, state) {
      this.buttonNumbers[id - 2].upTrick = state;
    },
    setDownTrick(id, state) {
      this.buttonNumbers[id - 2].downTrick = state;
    },
  
    resetUpDownTrick(id) {
      if (
        Model.upCriterioTrick(id) ||
        Model.downCriterioTrick(id) ||
        Model.updownCriterioTrick(id)
      ) {
        if (Model.upCriterioTrick(id)) {
          Model.setUpTrick(id, "active");
          Model.setDownTrick(id, "inactive");
        }
        if (Model.downCriterioTrick(id)) {
          Model.setUpTrick(id, "inactive");
          Model.setDownTrick(id, "active");
        }
        if (Model.updownCriterioTrick(id)) {
          Model.setUpTrick(id, "active");
          Model.setDownTrick(id, "active");
        }
      } else {
        Model.setUpTrick(id, "inactive");
        Model.setDownTrick(id, "inactive");
      }
    },
    toggleButtonState(id) {
      const button = this.buttonNumbers.find((btn) => btn.id === id);
      if (button) {
        button.state = button.state === "active" ? "inactive" : "active";
      }
    },
    setSelectedButton(button) {
      this.selectedButton = button;
    },
    toggleCardSelected(button) {
      if (this.selectedButton) {
        this.selectedButton = null;
      } else {
        this.setSelectedButton(button);
      }
    },
    setLastCardPlayed(handid) {
      this.lastCardPlayed.push({
        id: handid,
      });
    },
  
    getSelectedButton() {
      return this.selectedButton;
    },
    setLevel(level) {
      this.last_number = parseInt(level);
    },
    setMinCard(minCard) {
      this.minCardPlayed = parseInt(minCard);
    },
    setColumn(column) {
      this.nro_colums = parseInt(column);
    },
    getLevel() {
      return this.last_number;
    },
    levelUp() {
      ////// console.log(Model.last_number);
      if (Model.last_number < 300) {
        Model.last_number = Model.last_number + 10;
      }
    },
    levelDown() {
      ////// console.log(Model.last_number);
      if (Model.last_number > 20) {
        Model.last_number = Model.last_number - 10;
      }
    },
    minCardUp() {
      ////// console.log(Model.last_number);
      if (Model.minCardPlayed < 8) {
        Model.minCardPlayed = Model.minCardPlayed + 1;
      }
    },
    minCardDown() {
      ////// console.log(Model.minCardPlayed);
      if (Model.minCardPlayed > 1) {
        Model.minCardPlayed = Model.minCardPlayed - 1;
      }
    },
    columnUp() {
      ////// console.log(Model.last_number);
  
      Model.nro_colums = Model.nro_colums + 1;
    },
    columnDown() {
      ////// console.log(Model.minCardPlayed);
      if (Model.minCardPlayed > 1) {
        Model.nro_colums = Model.nro_colums - 1;
      }
    },
  
    canAddCard(type_target, newCardId, existingCardId) {
      // console.log("canAddCard");
      // console.log(newCardId);
      // console.log(existingCardId);
      if (type_target == "desc") {
        return Model.canAddTodesc(newCardId, existingCardId);
      }
      if (type_target == "asc") {
        return Model.canAddToasc(newCardId, existingCardId);
      }
    },
    canAddToasc(newCardId, existingCardId) {
      ////// console.log("canAddToasc");
      if (parseInt(newCardId) > parseInt(existingCardId)) {
        return 1;
      }
      if (Math.abs(newCardId - existingCardId) === 10) {
        return 2;
      }
    },
    canAddTodesc(newCardId, existingCardId) {
      //// console.log("canAddTodesc");
      ////// console.log(newCardId);
      ////// console.log(existingCardId);
      ////// console.log(newCardId < existingCardId);
      ////// console.log(Math.abs(newCardId - existingCardId === 10));
      if (parseInt(newCardId) < parseInt(existingCardId)) {
        return 1;
      }
      if (parseInt(newCardId) - parseInt(existingCardId) === 10) {
        return 2;
      }
    },
    isAcceptableTarget(targetColum) {
      // console.log(" isAcceptableTarget");
      // console.log(targetColum.classList.contains("column_game"));
      return targetColum.classList.contains("column_game");
    },
    upCriterioTrick(number) {
      // console.log("upCriterioTrick");
      //down posible posible only
      // console.log(number);
      //// console.log(Model.last_number);
      //// console.log(number + 10);
      value = number + 10 <= Model.last_number - 1;
      // console.log(value);
      return value;
    },
    downCriterioTrick(number) {
      // console.log("  downCriterioTrick");
      // console.log(number);
      //// console.log(Model.last_number);
      //down active posible only
      value = number - 10 >= 2 && 1;
      // console.log(value);
      return value;
    },
    updownCriterioTrick(number) {
      //// console.log("  updownCriterioTrick");
      //// console.log(number);
      //// console.log(Model.last_number);
      //down active posible only
      return this.upCriterioTrick(number) && this.downCriterioTrick(number);
    },
  
    updateTrickPosible(id) {
      let up = id + 10;
      let down = id - 10;
      buttonCard = Model.buttonNumbers[id - 2];
  
      if (Model.upCriterioTrick(id)) {
        // console.log("si");
        buttonUp = Model.buttonNumbers[up - 2];
  
        // console.log(buttonCard);
        // console.log(buttonUp);
        if (Model.downCriterioTrick(up)) {
          if (buttonCard.state == "active") {
            buttonUp.downTrick = "active";
          } else {
            buttonUp.downTrick = "inactive";
          }
        }
        // console.log(buttonUp);
  
        if (buttonUp.state == "active") {
          buttonCard.upTrick = "active";
        } else {
          buttonCard.upTrick = "inactive";
        }
  
        // console.log(buttonDown);
  
        // View.upCriterio(buttonCard, up_button);
      }
      if (Model.downCriterioTrick(id)) {
        // console.log("si");
        buttonDown = Model.buttonNumbers[down - 2];
        //// console.log(buttonCard);
        //// console.log(buttonDown);
        if (Model.upCriterioTrick(down)) {
          if (buttonCard.state == "active") {
            buttonDown.upTrick = "active";
          } else {
            buttonDown.upTrick = "inactive";
          }
        }
        //console.log(buttonDown);
  
        if (buttonDown.state == "active") {
          buttonCard.downTrick = "active";
        } else {
          buttonCard.downTrick = "inactive";
        }
        // // console.log(buttonDown);
      }
    },
    randomNumber(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    },
  };