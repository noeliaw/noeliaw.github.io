
// View
//The View will handle all UI-related logic, such as displaying buttons,
//showing/hiding elements, and updating the DOM.
const View = {
    container: document.getElementById("container_numbers"),

    button__deck: document.getElementById("button__deck"),
    button__show: document.querySelector("#button__show"),
    button__undo: document.getElementById("button__undo"),
    button__reset: document.getElementById("button__reset"),
    button__history: document.getElementById("button__history"),
    button__helper: document.getElementById("button__helper"),
    button__game: document.getElementById("button__game"),
    button__exit: document.getElementById("button__exit"),
  
    last_number: document.querySelector("#last-number"),
    min_card: document.querySelector("#min-card"),
    list_history: document.getElementById("list_history"),
  
    container_hand: document.getElementById("container_hand"),
    cont: document.getElementById("container_game"),
    fromcolumn: document.querySelector("#fromcolumn"),
    tocolumn: document.querySelector("#tocolumn"),
    column_number: document.querySelector("#column-number"),
    upCard: document.querySelector("#min-card-up"),
    downCard: document.querySelector("#min-card-down"),
    button__help: document.getElementById("hint-off"),
    upColumn: document.querySelector("#column-up"),
    downColumn: document.querySelector("#column-down"),
    downLevel: document.querySelector("#level-down"),
    upLevel: document.querySelector("#level-up"),
    lastCardPlayedElem:null, 
      
     
  
    up_icon:
      '<svg class="icon icon-circle-up"><use xlink:href="#icon-circle-up"></use></svg>',
    down_icon:
      '<svg class="icon icon-circle-down"><use xlink:href="#icon-circle-down"></use></svg>',
    
    
    renderAllColumns(nro_columns,last_number){
      for (let i = 1; i < nro_columns + 1; i++) {
        if (i % 2 === 0) {
          value = "asc";
          number = 1;
          icon = View.up_icon;
          id = i;
        } else {
          value = "desc";
  
          number = last_number;
          icon = View.down_icon;
          id = i;
        }
  
        View.renderColumn(
          View.fromcolumn,
          View.tocolumn,
          View.cont,
          icon,
          id,
          value,
          number,
          last_number
        );
        // console.log(fromcolumn);
      }
    },
      
    setlasCardPlayed(lastCardId){
    //console.log(lastCardId);
    //console.log(document.querySelector("#hand" + lastCardId));
       this.lastCardPlayedElem = document.querySelector("#hand" + lastCardId);
    },
    appendChild(parentSelector,childSelector){
    //console.log( document.querySelector(parentSelector));
    //console.log( child);
      document.querySelector(parentSelector).appendChild(document.querySelector(childSelector));
    },
    counter_button(number, text, class_text) {
      return (
        '<button item="' +
        number +
        '"class="' +
        class_text +
        '" ' +
        text +
        ">" +
        View.up_icon +
        "<div>" +
        number +
        "</div>" +
        View.down_icon +
        "</button>"
      );
    },
    renderColumn(
      fromcolumn,
      tocolumn,
      cont,
      icon,
      id,
      value,
      number,
      last_number
    ) {
      cont.innerHTML =
        cont.innerHTML +
        '<a class="column_game" id="game' +
        id +
        '" value="' +
        value +
        '"> <button class="button__card  column_game game   fix" item="' +
        number +
        '">' +
        "<p>" +
        number +
        "</p>" +
        icon +
        "</button>";
  
      if (value == "asc") {
        fromcolumn.innerHTML =
          fromcolumn.innerHTML +
          '<div class="from"><h2>From</h2><span>1</span></div>';
        tocolumn.innerHTML =
          tocolumn.innerHTML +
          '<div class="from"><h2>To</h2><span>' +
          last_number +
          "</span></div>";
      } else {
        fromcolumn.innerHTML =
          fromcolumn.innerHTML +
          '<div class="from"><h2>From</h2><span>' +
          last_number +
          "</span></div>";
        tocolumn.innerHTML =
          tocolumn.innerHTML +
          '<div class="from"><h2>To</h2><span>1</span></div>';
      }
    },
  
    renderStatistics(time, cards_left, tricksMade, minCardPlayed, last_number,undo) {
      var statistics = document.getElementById("statistics");
      statistics.innerHTML ='<div class="grid-3">'+
        '<div > <h2>Time</h2><span id="timer">' +
        time +
        "</span></div>" +
        "<div><h2>Left</h2>" +
        cards_left +
        "</div>" +
        "<div><h2>Undo's</h2>" +
        undo +
        "</div>" +'</div><div class="grid-3">'+
        "<div><h2>Tricks</h2>" +
        tricksMade +
        "</div>" +
        "<div><h2>Minimun</h2>" +
        minCardPlayed +
        "</div>" +
        "<div><h2>Level</h2>" +
        last_number +
        "</div></div>";
      statistics.classList.add("show");
    },
    renderButtons(button_numbers) {
      // console.log("render-buttons");
      View.container.innerHTML = "";
      // Logic to render buttons based on the model
      last_number = button_numbers.length + 2;
  
      class_text = "button__fix button--primary show  active fix w100";
      View.container.innerHTML += View.counter_button(1, "disabled", class_text);
  
      View.container.innerHTML +=
        '<section class="show"><div class="div__container_numbers grid show" id="container"><br></div></section>';
      container_numbers = document.querySelectorAll(".div__container_numbers")[0];
  
      button_numbers.forEach((button) => {
        let number = button.id;
        let text = ' id="button' + number + '"';
        let class_text = "button__number " + button.state + " ";
  
        if (number == 1 || number == last_number) {
          //  //// console.log("no imprimi botton"+number);
        } else {
          container_numbers.innerHTML += View.counter_button(
            number,
            text,
            class_text
          );
        }
      });
      class_text = "button__fix button--primary show  active fix w100";
      View.container.innerHTML += View.counter_button(
        last_number,
        "disabled",
        class_text
      );
    },
  
    renderButtonCard(button) {
      id = button.id;
      let buttonId = "hand" + id;
      let classCard = "button__card hand";
      if (button.upTrick == "active") {
        classCard += " up-active";
      }
      if (button.downTrick == "active") {
        classCard += " down-active";
      }
      let buttonCard =
        '<button class="' +
        classCard +
        '"id="' +
        buttonId +
        '" item="' +
        id +
        '">' +
        View.up_icon +
        id +
        View.down_icon +
        "</button>";
      View.renderButtonHand(buttonCard);
  
      // buttons_numbers[randomIdInt - 2].classList.remove("active");
    },
    toggleShowBody() {
      document.body.classList.toggle("icons-hidden");
    },
    trickClass(button, buttonElem) {
      buttonElem.classList.remove("down-active");
      buttonElem.classList.remove("up-active");
  
      if (button.downTrick == "active") {
        buttonElem.classList.add("down-active");
      }
      if (button.upTrick == "active") {
        buttonElem.classList.add("up-active");
      }
    },
    resetInnerHTML(elem){
      elem.innerHTML = "";
      
    },
    renderTrickHand(button) {
      //console.log(" renderTrick");
      //// console.log(button);
      id = button.id;
      buttonElem = document.getElementById("hand" + id);
      if (buttonElem){
      View.trickClass(button, buttonElem);
    }
    },
    renderTrick(button) {
      //// console.log(" renderTrick");
      //console.log(button);
      id = button.id;
      buttonElem = document.getElementById("button" + id);
      if (buttonElem){
        View.trickClass(button, buttonElem);
      }
    },
    toggleHiddenPlayedCards(nro_columns) {
       console.log("toggleHiddenPlayedCards");
      // //// console.log(btns);
      // //// console.log( btns.length);
      for (let i = 1; i < nro_columns + 1; i++) {
        targetId = "game" + i;
        let btns = document.querySelectorAll(
          "#" + targetId + " > .button__card:not(.fix)"
        );
       // console.log(btns);
        for (let j = 0; j < btns.length - 3; j++) {
          btns[j].classList.toggle("hidden");
          ////// console.log( btns[i]);
        }
      }
    },
    hideLevelInput() {
      View.removeClass("show", "#last-number");
      View.removeClass("show", "#level-down");
      View.removeClass("show", "#level-up");
      View.removeClass("show", "#level-down > .icon-minus");
      View.removeClass("show", "#level-up > .icon-plus");
    },
    showLevelInput() {
      View.addClass("show", "#container_level");
      View.addClass("show", "#last-number");
      View.addClass("show", "#level-down");
      View.toggleShow("#level-up");
      View.addClass("show", "#level-down > .icon-minus");
      View.addClass("show", "#level-up > .icon-plus");
    },
    renderInnerHtml(selector, message) {
      var messages_game = document.querySelector(selector);
      messages_game.innerHTML = message;
      messages_game.classList.add("show");
    },
    renderButtonHand(buttonHand) {
      let container_hand = document.getElementById("container_hand");
      container_hand.innerHTML += buttonHand;
    },
    renderHistory(buttonId) {
      let date = new Date();
      let options = { hour: "2-digit", minute: "2-digit", second: "2-digit" };
      View.list_history.innerHTML =
        `<p>${buttonId} ---- ${date.toLocaleString("en-US", options)}</p>` +
        View.list_history.innerHTML;
    },
  
    toggleShow(selector) {
      let elem = document.querySelector(selector);
      elem.classList.toggle("show");
    },
  
    removeClass(classRemove, selector) {
      
      let elem = document.querySelector(selector);
      if (elem){
      elem.classList.remove(classRemove);
    }
    },
    addClass(classAdd, selector) {
      let elem = document.querySelector(selector);
      if (elem){
      elem.classList.add(classAdd);
    }
    },
    cardSelected(card) {
      card.classList.add("selected");
      //// console.log(event.currentTarget);
    },
    cardUnSelected(card) {
      card.classList.remove("selected");
    },
    updateButtonState(button) {
      id = button.id;
      buttonElem = document.querySelector("#button" + button.id);
  
      if (button.state == "active") {
        // Deselect the button and update its classes
        buttonElem.classList.add("active");
      } else {
        buttonElem.classList.remove("active");
      }
    },
   
    hideButtons() {
      // console.log("hidebuttons");
      for (let i = 1; i < Model.nro_colums + 1; i++) {
        targetId = "game" + i;
  
        let btns = document.querySelectorAll("#" + targetId + " > .button__card");
  
        for (let i = 1; i < btns.length - 3; i++) {
          btns[i].classList.add("hidden");
        }
        for (let i = 1; i < btns.length - 1; i++) {
          btns[i].classList.add("hide");
        }
      }
    },
    showInactiveHelper() {
      View.toggleShow("#container");
      View.toggleShow("button svg.icon-eye");
      View.toggleShow("button svg.icon-eye-blocked");
    },
    disabledSelector(selector, logicValue) {
      //// console.log(logicValue);
      let elem = document.querySelectorAll(selector);
      elem.forEach((btn) => {
        btn.disabled = logicValue;
      });
    },
    counterClick() {
      View.hideLevelInput();
  
      View.removeClass("show", "#button__game");
      View.toggleShow("#container_numbers");
      View.addClass("show", "#button__reset");
      View.addClass("show", "#button__exit");
      View.addClass("show", "#container_exit");
      View.toggleShow("#container_help_btn");
      View.removeClass("show", "#container_level");
      View.removeClass("show", "#button__helper");
      View.removeClass("show", "#container_history");
    },
    handCardPlayed(selectedButton, newCardId) {
      //// console.log(selectedButton);
  
      selectedButton.classList.remove("hand", "selected");
      selectedButton.classList.remove("hand");
      selectedButton.classList.remove("selected");
  
      View.renderHistory(newCardId);
    },
    //static
  
    staticEventListeners() {
      Controller.handleResetClick();
  
      Controller.handleExitClick();
      Controller.handleGameClick();
      Controller.handleHistoryClick();
      Controller.handleShowClick();
      Controller.handleCounterClick();
      Controller.handleHintOffClick();
      Controller.handleUndoClick();
      //configuracion
      Controller.handleMinCards();
      Controller.handleNumCards();
    },
  };