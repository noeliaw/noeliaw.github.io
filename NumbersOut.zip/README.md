# Numbers Out Game
# Android App autoupdates from https://noeliawalterpro.github.io/version.json
# Autor: https://noeliawalterpro.github.io/
