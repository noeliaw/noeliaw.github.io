# Numbers Out Game
# Android App autoupdates from https://noeliawalterpro.github.io/version.json
# Autor: https://noeliawalterpro.github.io/

Por agregar 

- Variacion  Cartas que te obligan a jugar una sobre de esta sino perder
11 22 33 44 55 66 77 88 
