const Stopwatch = {
    startTime: null,
    elapsedTime: 0,
    timerId: null,
    tricksMade: 0,
  
    start() {
      if (this.timerId !== null) {
        clearInterval(this.timerId); // Reset the timer if it's already running
      }
  
      this.startTime = Date.now() - this.elapsedTime; // Adjust for any previous time
      this.timerId = setInterval(() => {
        this.elapsedTime = Date.now() - this.startTime;
        this.displayTime(this.elapsedTime);
      }, 1000); // Update every second
    },
  
    stop() {
      let time = this.elapsedTime;
      clearInterval(this.timerId);
      this.timerId = null;
      this.displayTime(time);
    },
  
    reset() {
      this.stop();
      this.elapsedTime = 0;
      this.displayTime(this.elapsedTime);
    },
  
    displayTime(milliseconds) {
      // Convert milliseconds to minutes and seconds
      const totalSeconds = Math.floor(milliseconds / 1000);
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
  
      const formattedTime = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  
      // Display the time on the page (assumes an element with id 'timer' exists)
      document.getElementById("timer").textContent = formattedTime;
    },
  };
  