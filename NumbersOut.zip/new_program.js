// Model
//The Model will store the game state and business logic,
//such as the number of cards, criteria for adding cards,
//and managing game states.
// Stopwatch Timer object to manage elapsed time

// Example usage: Start the timer when the game starts
document.addEventListener("DOMContentLoaded", () => {
  // Assuming the game starts when the "Start Game" button is clicked
  document.getElementById("button__game").addEventListener("click", () => {
    Stopwatch.start(); // Start the stopwatch when the game starts
  });

  // Optional: Stop and reset the stopwatch when the game ends
  document.getElementById("button__exit").addEventListener("click", () => {
    Stopwatch.stop();
  });

  document.getElementById("button__reset").addEventListener("click", () => {
    Stopwatch.reset();
    Stopwatch.start(); // Start the stopwatch when the game starts
  });
});


// Example game logic
function checkWinCondition() {
  // Your game logic to check if the player has won
  const hasWon = true; // This should be replaced with your actual win condition
  if (hasWon) {
    triggerWinAnimation();
  }
}