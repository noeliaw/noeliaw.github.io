// Controller
//The Controller will manage the interactions between the Model and View.
// It listens to user events, updates the Model, and reflects those changes
//in the View.
const Controller = {
  
  init() {
    Controller.handleNumColumns();
  
    Model.setLevel(View.last_number.innerHTML);

    View.showLevelInput();
    // View.resetCounter();
    Model.initializeButtons();
    // console.log(Model.buttonNumbers);
    View.renderButtons(Model.buttonNumbers);

    View.staticEventListeners();
    View.addClass("icons-hidden", "body");

    //View.showInactiveHelper();
  },
  renderBaseGame() {
    View.resetInnerHTML(View.container_hand);
    View.resetInnerHTML(View.tocolumn);
    View.resetInnerHTML(View.fromcolumn);
    Model.setLevel(View.last_number.innerHTML);
    Model.setColumn(View.column_number.innerHTML);

    View.resetInnerHTML(View.cont);
    // console.log(Model.nro_colums);
    View.renderAllColumns(Model.nro_colums, Model.last_number);

    // console.log(cont);
  },
  reset() {
    Model.resetFirstTime();
    Model.resetButtonNumbers();
    Controller.resetUpDownTrick();
    Model.resetUndo();
    View.resetInnerHTML(View.list_history);

    if (Model.mode == "game") {
      View.addClass("show", "#container_hand");
      Model.resetActiveHand();
      Controller.renderBaseGame();
      Model.initialCardsPlayed();
      Model.initialTricksMade();

      Controller.deck();
    }
  },

  resetUpDownTrick() {
    Model.buttonNumbers.forEach((button) => {
      let id = button.id;
      View.updateButtonState(button);
      Model.resetUpDownTrick(id);
      //  // console.log(id);
      View.renderTrick(button);
    });
  },
  handleDeckClick() {
    View.button__deck.addEventListener("click", function () {
      Controller.deck();
    });
  },
  handleUndoClick() {
    // console.log("handleUndoClick");
    View.button__undo.addEventListener("click", function () {
      lastElement = Model.getLastCardPlayed();

      Controller.undoCard(lastElement.id);
      if (Model.lastCardPlayed == 0) {
        View.removeClass("show", "#button__undo");
      }
    });
  },
  handleHintOffClick() {
    View.button__help.addEventListener("click", function () {
      View.toggleShowBody();
      View.toggleShow("#fromcolumn");
      View.toggleShow("#tocolumn");
      View.counterClick();
    });
  },
  ///min CARD
  handleMinCards() {
    Controller.handleMinusMinCardClick();
    Controller.handlePlusMinCardClick();
  },
  handleMinusMinCardClick() {
    View.downCard.addEventListener("click", Controller.handleMinCardDown);
  },
  handlePlusMinCardClick() {
    View.upCard.addEventListener("click", Controller.handleMinCardUp);
  },
  handleMinCardUp() {
    //// console.log("level Up");
    Model.minCardUp();
    View.renderInnerHtml("#min-card", Model.minCardPlayed);
    View.resetCounter();
    Controller.gameInit();
  },
  handleMinCardDown() {
    //// console.log("level down");
    Model.minCardDown();
    View.renderInnerHtml("#min-card", Model.minCardPlayed);
    Controller.gameInit();
  },
  /////-----------------------------/////
  ///num columns
  handleNumColumns() {
    Controller.handleMinusColumnClick();
    Controller.handlePlusColumnClick();
    Controller.renderBaseGame();
  },
  handleMinusColumnClick() {
    View.downColumn.addEventListener("click", Controller.handleColumnDown);
  },
  handlePlusColumnClick() {
    View.upColumn.addEventListener("click", Controller.handleColumnUp);
  },
  handleColumnUp() {
    //// console.log("level Up");

    Model.columnUp();

    View.renderInnerHtml("#column-number", Model.nro_colums);

    Controller.gameInit();
  },
  handleColumnDown() {
    //// console.log("level down");
    Model.columnDown();
    View.renderInnerHtml("#column-number", Model.nro_colums);
    Controller.gameInit();
  },
  ///NUMCARDS
  handleNumCards() {
    Controller.handleMinusClick();
    Controller.handlePlusClick();
  },
  handleMinusClick() {
    View.downLevel.addEventListener("click", Controller.handlelevelDown);
  },
  handlePlusClick() {
    View.upLevel.addEventListener("click", Controller.handlelevelUp);
  },
  handlelevelUp() {
    //// console.log("level Up");

    Model.levelUp();

    View.renderInnerHtml("#last-number", Model.last_number);
    Model.setLevel(View.last_number.innerHTML);

    Controller.gameInit();
  },
  handlelevelDown() {
    //// console.log("level down");
    Model.levelDown();

    View.renderInnerHtml("#last-number", Model.last_number);
    Model.setLevel(View.last_number.innerHTML);

    Controller.gameInit();
  },
  /////-----------------------------/////
  updateMode() {
    if (Model.mode == "game") {
      //// console.log(Model.mode);
      View.disabledSelector(".div__container_numbers > .button__number", true);
    } else {
      //// console.log(Model.mode);
      View.disabledSelector(".div__container_numbers > .button__number", false);
    }
  },
  handleButtonCounterClick() {
    let buttons_numbers = document.querySelectorAll(
      ".div__container_numbers > .button__number"
    );
    buttons_numbers.forEach((button) => {
      button.addEventListener("click", function () {
        // console.log("handleButtonCounterClick");
        let buttonId = button.getAttribute("id").replace(/[^\d]/g, "");
        // console.log(buttonId);
        Controller.updateButtonState(Model.buttonNumbers[buttonId - 2]);
      });
    });
  },
  updateButtonState(buttonCard) {
    // console.log(" updateButtonState");
    Model.toggleButtonState(buttonCard.id);
    View.updateButtonState(buttonCard);
    View.renderHistory(buttonCard.id);
    Controller.updateTrickPosible(buttonCard);
  },
  handleResetClick() {
    View.button__reset.addEventListener("click", function () {
      Controller.reset();
    });
  },
  removeTrickAnimation() {
    View.removeClass("star-border", ".star-border");
  },
  handlebuttonHandClick() {
    document.querySelectorAll(".button__card.hand").forEach((btn) => {
      btn.addEventListener(
        "click",
        Controller.handleCardClick,
        Controller.removeTrickAnimation()
      );
    });
  },
  columnTargetStaticClick() {
    document.querySelectorAll(".column_game > svg").forEach((target) => {
      // //// console.log('Immediate Parent:', target.parentElement);
      target.parentElement.addEventListener(
        "click",
        Controller.handleTargetClick
      );
    });

    document.querySelectorAll(".column_game ").forEach((target) => {
      ////// console.log('Immediate Parent:', target.parentElement);
      target.parentElement.addEventListener(
        "click",
        Controller.handleTargetClick
      );
    });
  },
  toggleAllCards() {
    
    if(Model.first_time==1){
    let selector = ".button__card.fix";
    // console.log(selector);
    let fix = document.querySelectorAll(selector);

    fix.forEach((btn) => {
      btn.addEventListener("click", function (event) {
        View.toggleHiddenPlayedCards(Model.nro_colums);
      });
    });
    Model.setFirstTimePass();
    
  }
  },
  columnTargetClick() {
    // console.log(" columnTargetClick");
    for (let i = 1; i < Model.nro_colums + 1; i++) {
      targetId = "game" + i;
      let targetElement = document.getElementById(targetId);
      if (targetElement) {
        targetElement.addEventListener("click", Controller.handleTargetClick);
      }
    }
  },
  handleHistoryClick() {
    View.button__history.addEventListener("click", () => {
      View.toggleShow("#container_history");
    });
  },
  handleCounterClick() {
    View.button__helper.addEventListener("click", function () {
      //// console.log("helper click");
      //// console.log(Model.mode);
      if (Model.mode == "game") {
      } else {
        Model.setHelperMode();
        View.renderStatistics();
        View.removeClass("show", "#statistics");

        //   debugger;
        Controller.gameInit();
        View.addClass("show", "#hint-off");
        View.removeClass("icons-hidden", "body");
      }

      View.counterClick();
    });
  },
  handleShowClick() {
    View.button__show.addEventListener("click", function () {
      View.showInactiveHelper();
    });
  },

  gameInit() {
    Model.setLevel(View.last_number.innerHTML);
    Model.setMinCard(View.min_card.innerHTML);

    Controller.renderBaseGame();
    Model.resetUndo();
    Model.initializeButtons();

    View.renderButtons(Model.buttonNumbers);
    View.renderStatistics();
    View.removeClass("show", "#statistics");

    Controller.updateMode();

    Controller.resetUpDownTrick();

    Controller.handleButtonCounterClick();
  },
  handleGameClick() {
    View.button__game.addEventListener("click", function () {
      // console.log("button_game");
      //// console.log(Model.mode);
      Model.setGameMode();
      //// console.log(Model.mode);
      View.renderStatistics();
      View.addClass("icons-hidden", "body");
      //reset.click();
      View.removeClass("show", "#container_history");
      Controller.handleDeckClick();
      Controller.columnTargetClick();
      
      Controller.gameInit();
      View.removeClass("show", "#container_level");
      View.removeClass("show", "#button__helper");
      Controller.renderBaseGame();
      // View.toggleShow('#button__helper');
      View.hideLevelInput();
      View.addClass("show", "#container_hand");
      View.removeClass("show", "#container");
      View.addClass("show", "#game");
      View.addClass("show", "#button__reset");
      View.removeClass("show", "#button__game");
      View.addClass("show", "#button__exit");
      View.addClass("show", "#button__exit");
      View.removeClass("show", "#messages");
      View.addClass("show", "#container_exit");
      View.addClass("show", "#statistics");
      View.addClass("show", "#container_exit");
      Controller.reset();
    });
  },
  handleExitClick() {
    View.button__exit.addEventListener("click", function () {
      Model.setHelperMode();
      Stopwatch.reset();

      View.showLevelInput();
      View.showInactiveHelper();
      View.removeClass("show", "#container_history");
      View.removeClass("icons-hidden", "body");
      View.addClass("show", "#container_level");
      View.addClass("show", "#button__helper");
      View.removeClass("show", "#button__reset");
      View.removeClass("show", "#container");
      View.removeClass("show", "#game");

      View.addClass("show", "#button__game");
      View.removeClass("show", "#button__exit");
      View.removeClass("show", "#container_numbers");
      View.removeClass("show", "#container_exit");

      Controller.reset();
      View.removeClass("show", "#container_exit");
      View.removeClass("show", "#statistics");
      View.removeClass("show", "#container_help_btn");
    });
  },
  updateTrickPosible(buttonCard) {
    // console.log(" updateTrickPosible");
    id = buttonCard.id;
    let down = id - 10;
    let up = id + 10;

    buttonCard = Model.buttonNumbers[id - 2];
    buttonDown = Model.buttonNumbers[down - 2];
    buttonUp = Model.buttonNumbers[up - 2];
    // console.log(buttonDown);
    // console.log(buttonCard);
    // console.log(buttonCard);
    //console.log(Model.last_number);
    //console.log(buttonCard);

    Model.updateTrickPosible(id);
    if (buttonUp) {
      View.renderTrick(buttonUp);
    }
    if (buttonDown) {
      View.renderTrick(buttonDown);
    }
    View.renderTrick(buttonCard);

    if (Model.mode == "game") {
      if (buttonUp) {
        View.renderTrickHand(buttonUp);
      }
      if (buttonDown) {
        View.renderTrickHand(buttonDown);
      }
      if (buttonCard) {
        View.renderTrickHand(buttonCard);
      }
    }
  },
  notPossibleToPlay() {
    // console.log("notPossibleToPlay");
    let notpossible = true;
    Model.activeHand.forEach((btn) => {
      newCardId = btn.id;
      for (let i = 1; i < Model.nro_colums + 1; i++) {
        targetId = "game" + i;
        ////// console.log(targetId);

        let buttons_played = document.querySelector(
          "#" + targetId + " > .button__card:last-of-type"
        );

        let existingCardId = buttons_played.getAttribute("item");
        let targetColum = document.querySelector("#" + targetId);
        let type_target = targetColum.getAttribute("value");
        // console.log(type_target);
        // console.log(newCardId);
        // console.log(existingCardId);
        if (
          Model.canAddCard(
            type_target,
            parseInt(newCardId),
            parseInt(existingCardId)
          ) >= 1
        ) {
          notpossible = false;
        }
      }
    });
    // console.log(notpossible);

    return notpossible;
  },
  deck() {
    var btn_h_size = Model.activeHand.length;
    let activeNumbers = Model.getActiveNumbers();
    let cardsToDraw = 8 - btn_h_size;

    //console.log("deckdraw");
    if (Model.selectedButton) {
      View.cardUnSelected(Model.selectedButton);
      Model.setNullSelectedButton();
    }
    if (Model.cards_played >= Model.minCardPlayed) {
      if (activeNumbers.length === 0) {
        View.renderInnerHtml("#messages", "No active buttons available.");

        return;
      } else {
        View.removeClass("show", "#button__undo");

        Model.resetLastCardPlayed();
        View.removeClass("show", "#messages");
        for (let i = 1; i < cardsToDraw + 1; i++) {
          activeNumbers = Model.getActiveNumbers();

          if (activeNumbers.length === 0) {
            break;
          } else {
            let isInHand = 1;
            let randomButton;
            let randomId;

            while (isInHand == 1) {
              let randomIndex = Model.randomNumber(0, activeNumbers.length - 1);
              randomButton = activeNumbers[randomIndex];
              randomId = randomButton.id;
              ////// console.log("random");
              ////// console.log(randomIdInt);
              isInHand = Model.checkIsInHand(randomId);

              if (isInHand == 1) {
                //console.log("is in hand");
              }
              if (Model.activeHand.length == Model.activeNumbers.length) {
                View.renderInnerHtml("#messages", "No more Cards");

                break;
              }
            }

            if (isInHand == 0) {
              //// console.log("is not in hand");
              // console.log(randomIdInt);
              // console.log(Model.buttonNumbers[randomIdInt - 2]);
              Model.setActiveHand(randomId);
              activeNumbers = Model.getActiveNumbers();

              View.renderButtonCard(Model.buttonNumbers[randomId - 2]);
            }
          }
        }

        Model.cards_played = 0;
        //// console.log(Model.cards_played);
      }
    } else {
      if (Controller.notPossibleToPlay()) {
        // console.log("notpossible is true");
        View.renderInnerHtml(
          "#messages",
          "Not posible to play, try again press reset"
        );
        View.addClass("show", "#messages");
        Stopwatch.stop();
      } else {
        activeNumbers.length === 0
          ? View.renderInnerHtml("#messages", "Can't draw cards")
          : View.renderInnerHtml(
              "#messages",
              "Play min " + Model.minCardPlayed + " cards"
            );
      }
    }

    // Attach click event listeners to all buttons in the hand
    Controller.handlebuttonHandClick();

    if (Model.activeHand.length == Model.activeNumbers.length) {
      if (Controller.notPossibleToPlay()) {
        View.renderInnerHtml(
          "#messages",
          "Not possible to play, try again press reset"
        );
        View.addClass("show", "#messages");
      } else {
        View.renderInnerHtml("#messages", "No more Cards");
      }
    }

    Model.activeHand.forEach((btn) => {
      Controller.updateTrickPosible(Model.buttonNumbers[btn.id - 2]);
    });

    //   container_hand.click();

    //   container_hand.click();
    Model.setCardsLeft();

    Controller.renderAllStatistics();
  },
  renderAllStatistics() {
    View.renderStatistics(
      Model.time,
      Model.cards_left,
      Model.tricksMade,
      Model.minCardPlayed,
      Model.last_number,
      Model.undo
    );
  },

  handleCardClick(event) {
    // Deselect any previously selected button
    //// console.log("handlecardclick");
    var card = event.currentTarget;

    // Select the clicked button

    //// console.log(Model.selectedButton);
    if (Model.selectedButton !== null) {
      //// console.log("selected button not null");
      View.cardUnSelected(Model.selectedButton);

      Model.selectedButton = card;
      View.cardSelected(card);
    } else {
      //// console.log("selected button null");

      Model.selectedButton = card;
      View.cardSelected(card);
    }
    // Attach click event listeners to all target elements
    Controller.columnTargetClick();
    Controller.removeTrickAnimation();
  },

  handCardPlayedEvent(selectedButton) {
    selectedButton.removeEventListener("click", Controller.handleCardClick);
    selectedButton.addEventListener("click", Controller.handleTargetClick);
  },
  lookforAcceptableTarget(targetColum) {
    if (Model.isAcceptableTarget(event.target)) {
      targetColum = event.currentTarget;
    } else {
      if (targetColum.parentNode.getAttribute("id") == "container_hand") {
        return;
      }
      targetColum = event.target.parentNode;
      // //// console.log(targetColum);
      if (Model.isAcceptableTarget(targetColum)) {
      } else {
        if (targetColum.parentNode.getAttribute("id") == "container_hand") {
          return;
        }
        targetColum = targetColum.parentNode;

        // //// console.log(targetColum);
        if (Model.isAcceptableTarget(targetColum)) {
        } else {
          if (targetColum.parentNode.getAttribute("id") == "container_hand") {
            return;
          }
          targetColum = targetColum.parentNode;

          //  //// console.log(targetColum);
          if (Model.isAcceptableTarget(targetColum)) {
          } else {
            if (targetColum.parentNode.getAttribute("id") == "container_hand") {
              return;
            }
            targetColum = targetColum.parentNode;

            //   //// console.log(targetColum);
          }
        }
      }
    }

    return targetColum;
  },
  undoCard(lastCardId) {
    // console.log("undoCard");
    // Get the currently selected button

    View.setlasCardPlayed(lastCardId);

    View.appendChild("#container_hand", "#hand" + lastCardId);
    View.addClass("hand", "#hand" + lastCardId, "#hand" + lastCardId);
    // Deselect the button and update its classes

    button = Model.buttonNumbers[lastCardId - 2];

    Model.setActiveButtonNumber(lastCardId);
    View.updateButtonState(button);
    View.lastCardPlayedElem.addEventListener(
      "click",
      Controller.handleCardClick
    );
    View.lastCardPlayedElem.removeEventListener(
      "click",
      Controller.handleTargetClick
    );

    Model.decreaseCardsPlayed();
    Model.increaseCardsLeft();
    Model.increaseUndo();

    Controller.renderAllStatistics();

    View.removeClass("show", "#messages");
    Controller.updateTrickPosible(button);
    Model.getActiveNumbers();
  },

  handleTargetClick(event) {
    // console.log("handleTarget");
    // Get the currently selected button

    //// console.log(event.currentTarget);
    // Proceed only if a button is selected
    if (Model.selectedButton) {
      let targetColum = event.currentTarget;
      // console.log(targetColum);
      Controller.lookforAcceptableTarget(targetColum); // Get the parent of the clicked target element
      // console.log(targetColum);

      if (Model.isAcceptableTarget(targetColum)) {
        //  //// console.log(targetColum);
        let existingCardId = targetColum.lastElementChild.getAttribute("item"); // Get the 'item' attribu
        //console.log("oldcard");
        ////// console.log(existingCardId);
        let type_target = targetColum.getAttribute("value");
        //  //// console.log("type targetElement");
        //  //// console.log(type_target);
        ////// console.log("endtargetElement");

        let newCardId = Model.selectedButton.getAttribute("item"); // Get the 'item' attribute
        //   //// console.log("newcard");
        //   //// console.log(newCardId);
        let canaddcard = Model.canAddCard(
          type_target,
          newCardId,
          existingCardId
        );
        // console.log(canaddcard);
        if (canaddcard >= 1) {
          // Move the selected button to the clicked target
          //  targetColum.appendChild(Model.selectedButton);
          let targetId = targetColum.getAttribute("id");
          View.appendChild("#" + targetId, "#hand" + newCardId);
          buttonNumber = Model.buttonNumbers[newCardId - 2];

          Model.setInactiveButtonNumber(newCardId);
          View.updateButtonState(buttonNumber);
          Controller.handCardPlayedEvent(Model.selectedButton, newCardId);

          Model.increaseCardsPlayed();
          Model.setCardsLeft();

          View.handCardPlayed(Model.selectedButton, newCardId);

          View.removeClass("show", "#messages");

          Controller.updateTrickPosible(Model.buttonNumbers[newCardId - 2]);
          if (canaddcard == 2) {
            View.addClass("star-border", "#hand" + newCardId);
            View.cardUnSelected(Model.selectedButton);

            Model.increaseTricksMade();

            setTimeout(() => {
              View.removeClass("star-border", ".star-border");
            }, 500);
          }

          Controller.renderAllStatistics();
          Model.setLastCardPlayed(parseInt(newCardId));

          View.addClass("show", "#button__undo");

          Model.removeActiveHand(parseInt(newCardId));

          Model.setNullSelectedButton();
        }

        if (0 == Model.activeNumbers.length) {
          View.renderInnerHtml("#messages", "Win");
          Stopwatch.stop();
          View.removeClass("show", "#container_hand");
          triggerWinAnimation();
        }
        Controller.toggleAllCards();
        // Add event listener to the first button
        View.hideButtons();
      }
    }
  },
};

// Initialize the game
document.addEventListener("DOMContentLoaded", () => {
  Controller.init();
});
