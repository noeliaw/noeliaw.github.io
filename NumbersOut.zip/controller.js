// Controller
//The Controller will manage the interactions between the Model and View.
// It listens to user events, updates the Model, and reflects those changes
//in the View.
const Controller = {
  init() {
    Controller.handleNumColumns();
    //Get level from html
    Model.setLevel(View.last_number.innerHTML);
    //show container configuration of the level
    View.showLevelInput();
    //Button Creation
    Model.initializeButtons();
    //Render Buttons
    View.renderButtons(Model.buttonNumbers);
    //Static Click Interaction
    View.staticEventListeners();
    //Hide help trick icons
    View.addClass("icons-hidden", "body");
  },
  reset() {
    //Set Active the Button Numbers
    Model.resetButtonNumbers();
    //Set the possible UP Down Trick
    Controller.resetUpDownTrick();
    //Set empty list history
    View.resetInnerHTML(View.list_history);

    //If Mode set as game
    if (Model.mode == "game") {
      //Show Container Hand
      View.addClass("show", "#container_hand");
      //Reset active hand to empty []
      Model.resetActiveHand();
      //Render Base del Juego
      Controller.renderBaseGame();
      //Reset CardsPlayed to min cards to be posible to draw
      Model.initialCardsPlayed();
      //Set 0 Tricks Made Counter
      Model.initialTricksMade();
      //Set 0 Undo Counter
      Model.resetUndo();
      //Draw from deck
      Controller.deck();

      View.addClass("show", "#container_hand");
      View.addClass("show", "#button__undo");
      View.addClass("show", "#hint-off");
      View.addClass("show", "#button__deck");
    }
  },

  resetUpDownTrick() {
    Model.buttonNumbers.forEach((button) => {
      let id = button.id;
      // Render Active and Inactive State
      View.updateButtonState(button);
      // Set Tricks possible
      Model.resetUpDownTrick(id);
      // Render Tricks acording to the variable
      View.renderTrick(button);
    });
  },

  ///min CARD

  handleMinusMinCardClick() {
    View.downCard.addEventListener("click", Controller.handleMinCardDown);
  },
  handlePlusMinCardClick() {
    View.upCard.addEventListener("click", Controller.handleMinCardUp);
  },
  handleMinCardUp() {
    Model.minCardUp();

    View.renderInnerHtml("#min-card", Model.minCardPlayed);
    View.renderDificulty(Model.minCardPlayed);

    Controller.gameInit();
  },
  handleMinCardDown() {
    Model.minCardDown();

    View.renderInnerHtml("#min-card", Model.minCardPlayed);
    View.renderDificulty(Model.minCardPlayed);

    Controller.gameInit();
  },
  /////-----------------------------/////
  ///num columns
  handleMinusColumnClick() {
    View.downColumn.addEventListener("click", Controller.handleColumnDown);
  },
  handlePlusColumnClick() {
    View.upColumn.addEventListener("click", Controller.handleColumnUp);
  },
  handleNumColumns() {
    Controller.handleMinusColumnClick();
    Controller.handlePlusColumnClick();
    Controller.renderBaseGame();
  },
  handleColumnUp() {
    Model.columnUp();

    View.renderInnerHtml("#column-number", Model.nro_colums);

    Controller.gameInit();
  },
  handleColumnDown() {
    Model.columnDown();

    View.renderInnerHtml("#column-number", Model.nro_colums);

    Controller.gameInit();
  },
  ///NUMCARDS

  handleMinusClick() {
    View.downLevel.addEventListener("click", Controller.handlelevelDown);
  },
  handlePlusClick() {
    View.upLevel.addEventListener("click", Controller.handlelevelUp);
  },
  handlelevelUp() {
    Model.levelUp();
 
    View.renderInnerHtml("#last-number", Model.last_number);

    Controller.gameInit();
  },
  handlelevelDown() {

    Model.levelDown();

    View.renderInnerHtml("#last-number", Model.last_number);
    
    Controller.gameInit();
  },
  /////-----------------------------/////
  updateMode() {
    if (Model.mode == "game") {
      View.disabledSelector(".div__container_numbers > .button__number", true);
    } else {
      View.disabledSelector(".div__container_numbers > .button__number", false);
    }
  },
  handleButtonCounterClick() {
    let buttons_numbers = document.querySelectorAll(
      ".div__container_numbers > .button__number"
    );
    buttons_numbers.forEach((button) => {
      button.addEventListener("click", function () {
        // console.log("handleButtonCounterClick");
        let buttonId = button.id.replace(/[^\d]/g, "");
        // console.log(buttonId);
        Controller.updateButtonState(Model.buttonNumbers[buttonId - 2]);
      });
    });
  },
  updateButtonState(buttonCard) {
    // console.log(" updateButtonState");
    Model.toggleButtonState(buttonCard.id);

    View.updateButtonState(buttonCard);
    View.renderHistory(buttonCard.id);

    Controller.updateTrickPosible(buttonCard);
  },

  columnTargetStaticClick() {
    document.querySelectorAll(".column_game > svg").forEach((target) => {
      // //// console.log('Immediate Parent:', target.parentElement);
      target.parentElement.addEventListener(
        "click",
        Controller.handleTargetClick
      );
    });

    document.querySelectorAll(".column_game ").forEach((target) => {
      ////// console.log('Immediate Parent:', target.parentElement);
      target.parentElement.addEventListener(
        "click",
        Controller.handleTargetClick
      );
    });
  },

  gameInit() {
    Model.setLevel(View.last_number.innerHTML);
    Model.setMinCard(View.min_card.innerHTML);
    Model.resetUndo();
    Model.initializeButtons();

    View.renderButtons(Model.buttonNumbers);
    View.renderStatistics();
    View.removeClass("show", "#statistics");

    Controller.renderBaseGame();
    Controller.updateMode();
    Controller.resetUpDownTrick();
    Controller.handleButtonCounterClick();
  },

  updateTrickPosible(buttonCard) {
    // console.log(" updateTrickPosible");
    id = buttonCard.id;
    let down = id - 10;
    let up = id + 10;

    buttonCard = Model.buttonNumbers[id - 2];
    buttonDown = Model.buttonNumbers[down - 2];
    buttonUp = Model.buttonNumbers[up - 2];

    Model.updateTrickPosible(id);
    if (buttonUp) {
      View.renderTrick(buttonUp);
    }
    if (buttonDown) {
      View.renderTrick(buttonDown);
    }
    View.renderTrick(buttonCard);

    if (Model.mode == "game") {
      if (buttonUp) {
        View.renderTrickHand(buttonUp);
      }
      if (buttonDown) {
        View.renderTrickHand(buttonDown);
      }
      if (buttonCard) {
        View.renderTrickHand(buttonCard);
      }
    }
  },
  getNumberFromText(str) {
    number = parseInt(str.replace(/[^\d]/g, ""), 10);
  },
  //game
  ///////////////////////////////////

  renderBaseGame() {
    Model.setLevel(View.last_number.innerHTML);
    Model.setColumn(View.column_number.innerHTML);
    Model.initColumns(Model.nro_colums);

    View.resetInnerHTML(View.container_hand);
    View.resetInnerHTML(View.tocolumn);
    View.resetInnerHTML(View.fromcolumn);
    View.resetInnerHTML(View.cont);
    View.renderAllColumns(Model.nro_colums, Model.last_number);
   
    Controller.toggleAllCards();
  },
  lookforAcceptableTarget(targetColum) {
    if (Model.isAcceptableTarget(event.target)) {
      targetColum = event.currentTarget;
    } else {
      if (targetColum.parentNode.id == "container_hand") {
        return;
      }
      targetColum = event.target.parentNode;
      // //// console.log(targetColum);
      if (Model.isAcceptableTarget(targetColum)) {
      } else {
        if (targetColum.parentNode.id == "container_hand") {
          return;
        }
        targetColum = targetColum.parentNode;
        // //// console.log(targetColum);
        if (Model.isAcceptableTarget(targetColum)) {
        } else {
          if (targetColum.parentNode.id == "container_hand") {
            return;
          }
          targetColum = targetColum.parentNode;
          //  //// console.log(targetColum);
          if (Model.isAcceptableTarget(targetColum)) {
          } else {
            if (targetColum.parentNode.id == "container_hand") {
              return;
            }
            targetColum = targetColum.parentNode;
            //   //// console.log(targetColum);
          }
        }
      }
    }

    return targetColum;
  },
  removeTrickAnimation() {
    View.removeClass("star-border", ".star-border");
  },
  handlebuttonHandClick() {
    document.querySelectorAll(".button__card.hand").forEach((btn) => {
      btn.addEventListener(
        "click",
        Controller.handleCardClick,
        Controller.removeTrickAnimation()
      );
    });
  },
  toggleAllCards() {
    let selector = ".button__card.fix";
    let fix = document.querySelectorAll(selector);

    fix.forEach((btn) => {
      btn.addEventListener("click", 
        View.toggleHiddenPlayedCards(Model.nro_colums)
      );
    });
  },

  notPossibleToPlay() {
    // console.log("notPossibleToPlay");
    let notpossible = true;
    Model.activeHand.forEach((btn) => {
      newCardId = btn.id;
      for (let i = 1; i < Model.nro_colums + 1; i++) {
        targetId = "game" + i;
        let buttons_played = document.querySelector(
          "#" + targetId + " > .button__card:last-of-type"
        );

        let existingCardId = buttons_played.getAttribute("item");
        let targetColum = document.querySelector("#" + targetId);
        let type_target = targetColum.getAttribute("value");

        if (
          Model.canAddCard(
            type_target,
            parseInt(newCardId),
            parseInt(existingCardId)
          ) >= 1
        ) {
          notpossible = false;
        }
      }
    });
    // console.log(notpossible);

    return notpossible;
  },
  deck() {
    console.log(Model.activeHand);
    var btn_h_size = Model.activeHand.length;
    let activeNumbers = Model.getActiveNumbers();
    let cardsToDraw = 8 - btn_h_size;

    //console.log("deckdraw");
    if (Model.selectedButton) {
      View.cardUnSelected(Model.selectedButton);

      Model.setNullSelectedButton();
    }
    if (Model.cards_played >= Model.minCardPlayed) {
      if (activeNumbers.length === 0) {
        View.renderInnerHtml("#messages", "No active buttons available.");

        return;
      } else {
        Model.resetLastCardPlayed();

        View.removeClass("show", "#button__undo");
        View.removeClass("show", "#messages");

        for (let i = 1; i < cardsToDraw + 1; i++) {
          activeNumbers = Model.getActiveNumbers();

          if (activeNumbers.length === 0) {
            break;
          } else {
            let isInHand = 1;
            let randomButton;
            let randomId;

            while (isInHand == 1) {
              let randomIndex = Model.randomNumber(0, activeNumbers.length - 1);
              randomButton = activeNumbers[randomIndex];
              randomId = randomButton.id;
              isInHand = Model.checkIsInHand(randomId);

              if (isInHand == 1) {
                console.log("is in hand");
              }
              if (Model.activeHand.length == Model.activeNumbers.length) {
                View.renderInnerHtml("#messages", "No more Cards");

                break;
              }
            }

            if (isInHand == 0) {
              //// console.log("is not in hand");
              // console.log(randomIdInt);
              // console.log(Model.buttonNumbers[randomIdInt - 2]);
              Model.setActiveHand(randomId);
              activeNumbers = Model.getActiveNumbers();

              View.renderButtonCard(Model.buttonNumbers[randomId - 2]);
            }
          }
        }

        Model.cards_played = 0;
        //// console.log(Model.cards_played);
      }
    } else {
      if (Controller.notPossibleToPlay()) {
        // console.log("notpossible is true");
        View.renderInnerHtml(
          "#messages",
          "Not posible to play, try again press reset"
        );
        View.addClass("show", "#messages");
        Stopwatch.stop();
      } else {
        activeNumbers.length === 0
          ? View.renderInnerHtml("#messages", "Can't draw cards")
          : View.renderInnerHtml(
              "#messages",
              "Play min " + Model.minCardPlayed + " cards"
            );
      }
    }

    // Attach click event listeners to all buttons in the hand
    Controller.handlebuttonHandClick();

    if (Model.activeHand.length == Model.activeNumbers.length) {
      if (Controller.notPossibleToPlay()) {
        View.renderInnerHtml(
          "#messages",
          "Not possible to play, try again press reset"
        );
        View.addClass("show", "#messages");
      } else {
        View.renderInnerHtml("#messages", "No more Cards");
      }
    }
    Model.activeHand.forEach((btn) => {

    Controller.updateTrickPosible(Model.buttonNumbers[btn.id - 2]);

    });

    Model.setCardsLeft();

    Controller.renderAllStatistics();
  },
  renderAllStatistics() {
    View.renderStatistics(
      Model.time,
      Model.cards_left,
      Model.tricksMade,
      Model.minCardPlayed,
      Model.last_number,
      Model.undo
    );
  },

  handleCardClick(event) {
    // Deselect any previously selected button
    //// console.log("handlecardclick");
    var card = event.currentTarget;

    // Select the clicked button

    //// console.log(Model.selectedButton);
    if (Model.selectedButton !== null) {
      View.cardUnSelected(Model.selectedButton);

      Model.selectedButton = card;

      View.cardSelected(card);
    } else {
      Model.selectedButton = card;

      View.cardSelected(card);
    }
    // Attach click event listeners to all target elements
    Controller.columnTargetClick();
    Controller.removeTrickAnimation();
  },
  undoHandCardPlayedEvent(selectedButton) {
    selectedButton.addEventListener("click", Controller.handleCardClick);
    selectedButton.removeEventListener("click", Controller.handleTargetClick);
  },
  handCardPlayedEvent(selectedButton) {
    selectedButton.removeEventListener("click", Controller.handleCardClick);
    selectedButton.addEventListener("click", Controller.handleTargetClick);
  },
  undoCard(lastCardId, targetId) {
    // console.log("undoCard");

    Model.setActiveButtonNumber(lastCardId);
    Model.setActiveHand(lastCardId);
    Model.decreaseCardsPlayed();
    Model.increaseCardsLeft();
    Model.increaseUndo();
    Model.getActiveNumbers();
    Model.removeCardFromColumn(parseInt(targetId));

    View.setlastCardPlayed(lastCardId);
    View.appendChild("#container_hand", "#hand" + lastCardId);
    View.addClass("hand", "#hand" + lastCardId, "#hand" + lastCardId);

    button = Model.buttonNumbers[lastCardId - 2];

    Controller.undoHandCardPlayedEvent(View.lastCardPlayedElem);
    Controller.renderAllStatistics();
    Controller.updateTrickPosible(button);

    View.removeClass("show", "#messages");
    View.updateButtonState(button);
  },
  columnTargetClick() {
    // console.log(" columnTargetClick");
    for (let i = 1; i < Model.nro_colums + 1; i++) {
      targetId = "game" + i;
      let targetElement = document.getElementById(targetId);
      if (targetElement) {
        targetElement.addEventListener("click", Controller.handleTargetClick);
      }
    }
  },

  handleTargetClick(event) {
    // console.log("handleTarget");
    // Proceed only if a button is selected
    if (Model.selectedButton) {
      let targetColum = event.currentTarget;
      // Get the parent of the clicked target element
      Controller.lookforAcceptableTarget(targetColum);

      if (Model.isAcceptableTarget(targetColum)) {
        let existingCardId = targetColum.lastElementChild.getAttribute("item"); // Get the 'item' attribu
        let type_target = targetColum.getAttribute("value");
        let newCardId = Model.selectedButton.getAttribute("item"); // Get the 'item' attribute
        let canaddcard = Model.canAddCard(
          type_target,
          newCardId,
          existingCardId
        );
        // console.log(canaddcard);
        if (canaddcard >= 1) {
          // Move the selected button to the clicked target
          let targetId = targetColum.id;
          let columnIndex = parseInt(targetId.replace(/[^\d]/g, ""), 10);
          buttonNumber = Model.buttonNumbers[newCardId - 2];


          Model.setLastColumnPlayed(columnIndex);
          Model.addCardToColumn(columnIndex, newCardId);
          Model.setInactiveButtonNumber(newCardId);
          Model.increaseCardsPlayed();
          Model.setCardsLeft();

          View.setlastCardPlayed(newCardId);
          View.appendChild("#" + targetId, "#hand" + newCardId);   
          View.handCardPlayed(Model.selectedButton, newCardId);
          View.updateButtonState(buttonNumber);
        
          Controller.handCardPlayedEvent(Model.selectedButton, newCardId);
          Controller.updateTrickPosible(Model.buttonNumbers[newCardId - 2]);

          if (canaddcard == 2) {
            View.addClass("star-border", "#hand" + newCardId);
            View.cardUnSelected(Model.selectedButton);

            Model.increaseTricksMade();

            setTimeout(() => {
              View.removeClass("star-border", ".star-border");
            }, 500);
          }

          Controller.renderAllStatistics();

          Model.setLastCardPlayed(parseInt(newCardId));
          Model.removeActiveHand(parseInt(newCardId));
          Model.setNullSelectedButton();

          View.removeClass("show", "#messages");
          View.addClass("show", "#button__undo");
        }

        if (0 == Model.activeNumbers.length) {
          View.renderInnerHtml("#messages", "Win");
          Stopwatch.stop();
          View.removeClass("show", "#container_hand");
          View.removeClass("show", "#button__undo");
          View.removeClass("show", "#hint-off");
          View.removeClass("show", "#button__deck");

          
          triggerWinAnimation();
        }

        // Add event listener to the first button
        View.hideButtons(Model.nro_colums);
      }
    }
  },
  handleDeckClick() {
    View.button__deck.addEventListener("click", function () {
      Controller.deck();
    });
  },

  //static
  ////////////////////////////////////////////
  handleResetClick() {
    View.button__reset.addEventListener("click", function () {
      Controller.reset();
    });
  },

  handleExitClick() {
    View.button__exit.addEventListener("click", function () {
      Model.setHelperMode();

      Stopwatch.reset();

      View.showLevelInput();
      View.showInactiveHelper();

      View.addClass("show", "#container_level");
      View.addClass("show", "#button__helper");
      View.addClass("show", "#button__game");

      View.removeClass("show", "#container_history");
      View.removeClass("icons-hidden", "body");
      View.removeClass("show", "#button__undo");
      View.removeClass("show", "#container_numbers");
      View.removeClass("show", "#container_exit");
      View.removeClass("show", "#button__reset");
      View.removeClass("show", "#container");
      View.removeClass("show", "#game");
      View.removeClass("show", "#container_exit");
      View.removeClass("show", "#statistics");
      View.removeClass("show", "#container_help_btn");

      Controller.reset();
    });
  },
  handleGameClick() {
    View.button__game.addEventListener("click", function () {
      // console.log("button_game");

      Model.setGameMode();

      View.renderStatistics();
      View.hideLevelInput();

      View.removeClass("show", "#container_history");
      View.removeClass("show", "#button__game");
      View.removeClass("show", "#messages");
      View.removeClass("show", "#container");
      View.removeClass("show", "#container_level");
      View.removeClass("show", "#button__helper");

      View.addClass("icons-hidden", "body");
      View.addClass("show", "#container_hand");
      View.addClass("show", "#game");
      View.addClass("show", "#button__reset");
      View.addClass("show", "#button__exit");
      View.addClass("show", "#button__exit");
      View.addClass("show", "#container_exit");
      View.addClass("show", "#statistics");
      View.addClass("show", "#container_exit");

      Controller.handleDeckClick();
      Controller.columnTargetClick();
      Controller.gameInit();
      Controller.renderBaseGame();

      Controller.reset();
    });
  },

  handleHistoryClick() {
    View.button__history.addEventListener("click", () => {
      View.toggleShow("#container_history");
    });
  },
  handleShowClick() {
    View.button__show.addEventListener("click", function () {
      View.showInactiveHelper();
    });
  },
  handleCounterClick() {
    View.button__helper.addEventListener("click", function () {
      //// console.log("helper click");
      //// console.log(Model.mode);
      if (Model.mode == "game") {
      } else {
        Model.setHelperMode();

        Controller.gameInit();

        View.renderStatistics();
        View.addClass("show", "#hint-off");
        View.removeClass("icons-hidden", "body");
        View.removeClass("show", "#statistics");
      }

      View.counterClick();
    });
  },
  handleHintOffClick() {
    View.button__help.addEventListener("click", function () {
      View.toggleShowBody();
      View.toggleShow("#fromcolumn");
      View.toggleShow("#tocolumn");
      View.counterClick();
    });
  },

  handleUndoClick() {
    // console.log("handleUndoClick");
    View.button__undo.addEventListener("click", function () {
      lastCard = Model.getLastCardPlayed();
      lastColumn = Model.getLastColumnPlayed();

      Controller.undoCard(lastCard.id, lastColumn);
      if (Model.lastCardPlayed == 0) {
        View.removeClass("show", "#button__undo");
      }
    });
  },
  handleMinCards() {
    Controller.handleMinusMinCardClick();
    Controller.handlePlusMinCardClick();
  },
  handleNumCards() {
    Controller.handleMinusClick();
    Controller.handlePlusClick();
  },
};
// Initialize the game
document.addEventListener("DOMContentLoaded", () => {
  Controller.init();
});
